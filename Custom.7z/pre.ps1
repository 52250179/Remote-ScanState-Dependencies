# Activate Windows with the original product key if present
$SLS = Get-CimInstance -ClassName SoftwareLicensingService
$OPKD = $SLS.OA3xOriginalProductKeyDescription
$OPK = $SLS.OA3xOriginalProductKey
if ($OPKD -like "*Professional*" -and -not [string]::IsNullOrWhiteSpace($OPK)) {
    cscript C:\Windows\System32\slmgr.vbs /ipk $OPK
    cscript C:\Windows\System32\slmgr.vbs /ato
}

# Activate Windows with a digital license if not already activated with a digital license
$LicenseInfo = Get-CimInstance -ClassName SoftwareLicensingProduct -Filter "ApplicationID='55c92734-d682-4d71-983e-d6ec3f16059f' AND PartialProductKey IS NOT NULL" | Select-Object -First 1 LicenseStatus
$IsKMSActivated = $LicenseInfo.Description -like "*KMS*"
if ($LicenseInfo.LicenseStatus -ne 1 -or $IsKMSActivated) {
    if (Test-Path "C:\Recovery\OEM\Activation\HWID_Activation.cmd") {
        & cmd /c "C:\Recovery\OEM\Activation\HWID_Activation.cmd /HWID"
    }
}

# Install or reinstall Office if necessary
$Office = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object { $_.DisplayName -Like '*Microsoft Office*' }
$Office21 = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object { $_.DisplayName -Match 'Microsoft Office Professional 2021 - en-us' }
$Office365 = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object { $_.DisplayName -Match 'Microsoft 365 - en-us' }
$Office365Enterprise = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object { $_.DisplayName -Match 'Microsoft 365 Apps for enterprise' }
$Office21Path = "C:\Recovery\OEM\Apps\Office21"
$Office365Path = "C:\Recovery\OEM\Apps\Office365"

if ([string]::IsNullOrWhiteSpace($Office) -and [string]::IsNullOrWhiteSpace($Office21) -and (Test-Path $Office21Path) -and (Test-Path "$Office21Path\setup.exe")) {
    Push-Location -Path $Office21Path
    & .\setup.exe /configure .\configuration.xml
    Pop-Location
} elseif ([string]::IsNullOrWhiteSpace($Office) -and [string]::IsNullOrWhiteSpace($Office365) -and [string]::IsNullOrWhiteSpace($Office365Enterprise) -and (Test-Path $Office365Path) -and (Test-Path "$Office365Path\setup.exe")) {
    Push-Location -Path $Office365Path
    & .\setup.exe /configure .\configuration.xml
    Pop-Location
}

# Add the Office Activation script to Windows Security's exclusions and activate Office if the script is present
if (Test-Path "C:\Recovery\OEM\Activation\Ohook_Activation.cmd") {
    Add-MpPreference -ExclusionPath "C:\Recovery\OEM\Activation\Ohook_Activation.cmd"
    Add-MpPreference -ExclusionProcess "C:\Recovery\OEM\Activation\Ohook_Activation.cmd"
    & cmd /c "C:\Recovery\OEM\Activation\Ohook_Activation.cmd /Ohook"
}
