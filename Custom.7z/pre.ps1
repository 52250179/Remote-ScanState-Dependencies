<#
.SYNOPSIS
    OEM Setup: Activate Windows + Install/Activate Office (dynamic edition, auto-discover installers).

.DESCRIPTION
    1. Activates Windows via embedded OEM key (matching current EditionID) or digital entitlement.
    2. Detects any existing Office install (MSI, Click-to-Run, or COM ProgIDs).
    3. Auto-discovers Office installer folders in C:\Recovery\OEM\Apps, prioritizes by folder name descending.
    4. Installs Office if not already present.
    5. Adds Defender exclusions for Office activation script and runs it if no Office apps are open.

.NOTES
    - No parameters needed.  
    - Designed to run as SYSTEM during OOBE or first-boot.
#>

[CmdletBinding()]
param()

#--- WINDOWS ACTIVATION -------------------------------------------------------
function Activate-Windows {
    # Check if already activated
    $SLP = Get-CimInstance -ClassName SoftwareLicensingProduct `
        -Filter "ApplicationID='55c92734-d682-4d71-983e-d6ec3f16059f' AND PartialProductKey IS NOT NULL" |
        Select-Object -First 1

    if ($SLP.LicenseStatus -eq 1 -and $SLP.Description -notlike '*KMS*') {
        return $true
    }

    # First try OEM activation
    $EditionId = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').EditionID
    $SLS = Get-CimInstance -ClassName SoftwareLicensingService
    
    if ($SLS.OA3xOriginalProductKey -and $SLS.OA3xOriginalProductKeyDescription -like "*$EditionId*") {
        cscript.exe "$env:WinDir\System32\slmgr.vbs" /ipk $SLS.OA3xOriginalProductKey | Out-Null
        cscript.exe "$env:WinDir\System32\slmgr.vbs" /ato | Out-Null
        return $true
    }

    # Fallback to HWID activation
    $ActivationScript = 'C:\Recovery\OEM\Activation\HWID_Activation.cmd'
    if (Test-Path $ActivationScript) {
        & cmd /c "$ActivationScript /HWID"
        return $true
    }

    return $false
}

#--- OFFICE DETECTION ---------------------------------------------------------
function Test-OfficeInstalled {
    foreach ($Ver in 12..16) {
        foreach ($Hive in @('HKLM:\Software\Microsoft\Office', 'HKLM:\Software\Wow6432Node\Microsoft\Office')) {
            $Path = Join-Path "$Hive\$Ver.0\Common\InstallRoot" 'Path'
            if (Test-Path $Path) { return $true }
        }
    }

    $C2rKey = 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
    if ((Test-Path $C2rKey) -and (Get-ItemPropertyValue -Path $C2rKey -Name VersionToReport -ErrorAction SilentlyContinue)) {
        return $true
    }
    return $false
}

#--- DISCOVER OFFICE INSTALLER FOLDERS -----------------------------------------
function Get-OfficeInstallerFolder {
    $Root = 'C:\Recovery\OEM\Apps'
    if (-not (Test-Path $Root)) { return $null }

    $Dirs = Get-ChildItem -Path $Root -Directory -Filter 'Office*' -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending
    return $Dirs | Select-Object -First 1
}

#--- OFFICE INSTALLATION ------------------------------------------------------
function Install-Office {
    param([string]$InstallerPath)

    $SetupPath = Join-Path $InstallerPath 'setup.exe'
    $ConfigPath = Join-Path $InstallerPath 'configuration.xml'
    
    if ((-not (Test-Path $SetupPath)) -or (-not (Test-Path $ConfigPath))) {
        return $false
    }

    Push-Location $InstallerPath
    $Process = Start-Process -FilePath $SetupPath -ArgumentList '/configure configuration.xml' -Wait -PassThru
    Pop-Location

    return $Process.ExitCode -eq 0
}

#--- CHECK FOR RUNNING OFFICE APPS --------------------------------------------
function Test-OfficeAppsOpen {
    $Apps = @('WINWORD','EXCEL','POWERPNT','OUTLOOK','ONENOTE','MSACCESS','MSPUB','VISIO','WINPROJ')
    $Running = Get-Process -Name $Apps -ErrorAction SilentlyContinue
    return $Running.Count -gt 0
}

#--- OFFICE ACTIVATION EXCLUSION & SCRIPT RUN ----------------------------------
function Activate-Office {
    $ActivationScript = 'C:\Recovery\OEM\Activation\Ohook_Activation.cmd'
    if (-not (Test-Path $ActivationScript)) { return $false }

    Add-MpPreference -ExclusionPath $ActivationScript -ErrorAction SilentlyContinue
    Add-MpPreference -ExclusionProcess (Split-Path $ActivationScript -Leaf) -ErrorAction SilentlyContinue

    & cmd /c "$ActivationScript /Ohook"
    return $true
}

#=== MAIN EXECUTION ===========================================================
# 1) Windows Activation
Activate-Windows | Out-Null

# 2) Office Installation
if (-not (Test-OfficeInstalled)) {
    $InstallerDir = Get-OfficeInstallerFolder
    if ($InstallerDir) {
        Install-Office -InstallerPath $InstallerDir.FullName | Out-Null
    }
}

# 3) Office Activation
if (-not (Test-OfficeAppsOpen)) {
    Activate-Office | Out-Null
}
